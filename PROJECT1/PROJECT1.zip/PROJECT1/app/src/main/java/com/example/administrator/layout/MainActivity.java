package com.example.administrator.layout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
        NavigationView navigationView;
       DrawerLayout drawerLayout;
       Context mContext;
       Toolbar toolbar;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);









    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
           int id= menuItem.getItemId();
           String title = menuItem.getTitle().toString();
           if(id==R.id.nav_purchase){
               Toast.makeText(mContext,title+"계정 정보를 확인하세요",Toast.LENGTH_SHORT).show();
           }
        else if(id==R.id.nav_refund){
            Toast.makeText(mContext,title+"아이크라잉~",Toast.LENGTH_SHORT).show();
        }
        else if(id==R.id.nav_reivew){
            Toast.makeText(mContext,title+"아라라라아아랑",Toast.LENGTH_SHORT).show();
        }
        else if(id==R.id.nav_question){
            Toast.makeText(mContext,title+"모요모요모요",Toast.LENGTH_SHORT).show();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return false;


    }
    public void innitset(){
        toolbar =(Toolbar)findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

    }
}

